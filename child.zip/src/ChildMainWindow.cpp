#include "../include/ChildMainWindow.h"

ChildMainWindow::ChildMainWindow(QWidget *parent)
        : QMainWindow(parent),
          gamesList(new QListWidget(this)),
          layout(new QGridLayout(this)),
          mainWidget(new QWidget(this)),
          minutes(new QLabel(this)),
          lvl(new QLabel(this)){
    setWindowTitle("Child Application");
    initLayout();
    initWidgets();
    initConnections();
}

void ChildMainWindow::initLayout() {
    layout->addWidget(gamesList, 0, 0, 10, 1);
    layout->addWidget(minutes, 0, 1, 1, 1);
    layout->addWidget(lvl, 1, 1, 1, 1);

    layout->setColumnStretch(0, 0);
    layout->setColumnStretch(1, 1);
}


void ChildMainWindow::initWidgets() {
    setCentralWidget(mainWidget);
    mainWidget->setLayout(layout);

    minutes->setText("Доступно 25 минут для игры");
    lvl->setText("Текущий уровень: 3");

    gamesList->addItem("GTA V");
    gamesList->addItem("Counter Strike: Global Offencive");
    gamesList->addItem("Spider-man 2");
}

void ChildMainWindow::initConnections() {

}