#ifndef SUCCESSCONTROL_CHILDMAINWINDOW_H
#define SUCCESSCONTROL_CHILDMAINWINDOW_H

#include <QMainWindow>
#include <QGridLayout>
#include <QWidget>
#include <QListWidget>
#include <QLabel>

class ChildMainWindow : public QMainWindow {
Q_OBJECT

public:
    explicit ChildMainWindow(QWidget* parent = nullptr);
private:
    void initLayout();
    void initWidgets();
    void initConnections();

    QListWidget* gamesList;
    QGridLayout* layout;
    QWidget* mainWidget;
    QLabel* minutes, *lvl;
};


#endif //SUCCESSCONTROL_CHILDMAINWINDOW_H
