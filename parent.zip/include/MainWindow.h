#ifndef SUCCESSCONTROL_MAINWINDOW_H
#define SUCCESSCONTROL_MAINWINDOW_H

#include <memory>
#include <QMainWindow>
#include <QGridLayout>
#include <QWidget>
#include <QLabel>
#include <QPushButton>
#include <QListWidget>

#include "ParentCentralWidget.h"
#include "ChildrenListWidget.h"

class MainWindow : public QMainWindow {
Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);

private:
    void initWidgets();
    void initLayout();
    void initConnections();


    std::shared_ptr<QWidget> centralWidget;
    std::shared_ptr<QGridLayout> mainLayout;
    std::shared_ptr<ChildrenListWidget> childrenListWidget;
    std::shared_ptr<ParentCentralWidget> parentCentralWidget;
};


#endif //SUCCESSCONTROL_MAINWINDOW_H
