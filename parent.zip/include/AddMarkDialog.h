#ifndef SUCCESSCONTROL_ADDMARKDIALOG_H
#define SUCCESSCONTROL_ADDMARKDIALOG_H


#include <QDialog>
#include <QComboBox>
#include <QPushButton>
#include <QLabel>
#include <QFormLayout>
#include <QDialogButtonBox>

class AddMarkDialog : public QDialog {
    Q_OBJECT
public:
    explicit AddMarkDialog(QWidget* parent = nullptr);
    QComboBox* subjectSelect;
    QComboBox* markSelect;
private:
    void initLayout();
    void initWidgets();
    void initConnections();

    QFormLayout* layout;
    QDialogButtonBox* buttonBox;

};


#endif //SUCCESSCONTROL_ADDMARKDIALOG_H
