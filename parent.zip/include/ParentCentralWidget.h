#ifndef SUCCESSCONTROL_PARENTCENTRALWIDGET_H
#define SUCCESSCONTROL_PARENTCENTRALWIDGET_H

#include "MarksWidget.h"
#include "SummaryWidget.h"
#include "PlotWidget.h"

#include <memory>

#include <QWidget>


class ParentCentralWidget : public QWidget {
Q_OBJECT
public:
    ParentCentralWidget(QWidget* parent = nullptr);
private:
    void initWidgets();
    void initLayout();
    void initConnections();

    std::shared_ptr<QGridLayout> mainLayout;
    std::shared_ptr<MarksWidget> marksWidget;
    std::shared_ptr<SummaryWidget> summaryWidget;
    PlotWidget* plotWidget;
};


#endif //SUCCESSCONTROL_PARENTCENTRALWIDGET_H
