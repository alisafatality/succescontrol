#ifndef SUCCESSCONTROL_CHILDRENLISTWIDGET_H
#define SUCCESSCONTROL_CHILDRENLISTWIDGET_H

#include "ChildItem.h"

#include <QPixmap>
#include <QListWidget>

class ChildrenListWidget : public QListWidget {
    Q_OBJECT
public:
    ChildrenListWidget(QWidget* parent = nullptr);

    void insertChild(const QString& fio);
private:

};


#endif //SUCCESSCONTROL_CHILDRENLISTWIDGET_H
