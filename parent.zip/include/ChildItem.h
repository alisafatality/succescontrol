#ifndef SUCCESSCONTROL_CHILDITEM_H
#define SUCCESSCONTROL_CHILDITEM_H

#include <QWidget>
#include <QString>
#include <QGridLayout>
#include <QLabel>

class ChildItem : public QWidget {
Q_OBJECT

public:
    ChildItem(QWidget *parent = nullptr);

    void setFIO(const QString &fio);

    void setAvatar(const QPixmap& pixmap);

private:
    void initLayout();

    void initWidgets();

    QGridLayout *layout;
    QLabel *avatar;
    QLabel *fio;
};

#endif //SUCCESSCONTROL_CHILDITEM_H
