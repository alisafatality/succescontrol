#ifndef SUCCESSCONTROL_MARKSWIDGET_H
#define SUCCESSCONTROL_MARKSWIDGET_H

#include "Mark.h"
#include "AddMarkDialog.h"

#include <memory>

#include <QWidget>
#include <QGridLayout>
#include <QLabel>
#include <QPushButton>
#include <QListWidget>

class MarksWidget : public QWidget {
    Q_OBJECT
public:
    MarksWidget(QWidget* parent = nullptr);

    void insertMark(int mark_, const QString& subject);

private:
    void initWidgets();
    void initLayout();
    void initConnections();

    std::shared_ptr<QGridLayout> mainLayout;
    std::shared_ptr<QLabel> marksLabel;
    std::shared_ptr<QPushButton> addMarkButton;
    std::shared_ptr<QListWidget> marksList;
};


#endif //SUCCESSCONTROL_MARKSWIDGET_H
