#ifndef SUCCESSCONTROL_SUMMARYWIDGET_H
#define SUCCESSCONTROL_SUMMARYWIDGET_H

#include <memory>

#include <QWidget>
#include <QMessageBox>
#include <QGridLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>

class SummaryWidget : public QWidget {
Q_OBJECT

public:
    SummaryWidget(QWidget *parent = nullptr);

private:
    void initWidgets();
    void initLayout();
    void initConnections();


    std::shared_ptr<QGridLayout> mainLayout;
    std::shared_ptr<QLabel> minutesTitleLabel, levelTitleLabel;
    std::shared_ptr<QLabel> minutesLabel, levelLabel;
    std::shared_ptr<QLineEdit> minutesEdit;
    std::shared_ptr<QPushButton> minutesAdd;
};


#endif //SUCCESSCONTROL_SUMMARYWIDGET_H
