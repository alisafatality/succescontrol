#ifndef SUCCESSCONTROL_PLOTWIDGET_H
#define SUCCESSCONTROL_PLOTWIDGET_H

#include "qcustomplot.h"

#include <QWidget>
#include <QDateTime>

class PlotWidget : public QCustomPlot {
  Q_OBJECT
public:
    PlotWidget(QWidget* parent = nullptr);
private:
    void init();
};


#endif //SUCCESSCONTROL_PLOTWIDGET_H
