#ifndef SUCCESSCONTROL_MARK_H
#define SUCCESSCONTROL_MARK_H

#include <QWidget>
#include <QString>
#include <QGridLayout>
#include <QLabel>

class Mark : public QWidget {
    Q_OBJECT
public:
    Mark(QWidget* parent = nullptr);

    void setMark(int mark);
    void setSubjectTitle(const QString& subject_title);

private:
    void initLayout();
    void initWidgets();

    QGridLayout* layout;
    QLabel* mark;
    QLabel* subject;
};


#endif //SUCCESSCONTROL_MARK_H
