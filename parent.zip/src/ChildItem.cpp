#include "../include/ChildItem.h"

ChildItem::ChildItem(QWidget *parent) :
        QWidget(parent),
        layout(new QGridLayout(this)),
        avatar(new QLabel(this)),
        fio(new QLabel(this)) {
    initLayout();
    initWidgets();
}

void ChildItem::setAvatar(const QPixmap& pixmap) {
    avatar->setPixmap(pixmap);
    avatar->setScaledContents(true);
    avatar->setMinimumSize(16,16);
    avatar->setSizePolicy(QSizePolicy::Ignored, QSizePolicy::Ignored);
}

void ChildItem::setFIO(const QString &fio) {
    this->fio->setText(fio);
}

void ChildItem::initLayout() {
    setLayout(layout);
    layout->addWidget(avatar, 0, 0, 1, 1);
    layout->addWidget(fio, 0, 1, 1, 4);
}

void ChildItem::initWidgets() {
    avatar->setAlignment(Qt::AlignCenter);
    avatar->setStyleSheet("background-color: #f2f2f2; border-radius: 16px; color: black;");
}