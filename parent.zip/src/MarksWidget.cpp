#include "../include/MarksWidget.h"

MarksWidget::MarksWidget(QWidget *parent) :
        QWidget(parent),
        mainLayout(std::make_shared<QGridLayout>()),
        marksLabel(std::make_shared<QLabel>()),
        addMarkButton(std::make_shared<QPushButton>()),
        marksList(std::make_shared<QListWidget>()) {
    initWidgets();
    initLayout();
    initConnections();
}

void MarksWidget::initWidgets() {
    setLayout(mainLayout.get());

    marksLabel->setText("Оценки");

    QPixmap pixmap("../assets/plus.png");
    QIcon addMarkIcon(pixmap);
    addMarkButton->setIcon(addMarkIcon);
    addMarkButton->setIconSize(QSize(16, 16));

    insertMark(5, "Информатика");
    insertMark(4, "Геометрия");
    insertMark(4, "Физика");
    insertMark(5, "Русский язык");
    insertMark(5, "Алгебра");
}

void MarksWidget::initLayout() {
    mainLayout->addWidget(marksLabel.get(), 0, 0, 1, 2, Qt::AlignLeft | Qt::AlignTop);
    mainLayout->addWidget(addMarkButton.get(), 0, 2, 1, 1, Qt::AlignRight | Qt::AlignTop);
    mainLayout->addWidget(marksList.get(), 1, 0, 9, 3);
}

void MarksWidget::initConnections() {
    connect(addMarkButton.get(), &QPushButton::clicked, this, [&]() {
        AddMarkDialog dialog(this);
        if (dialog.exec() == QDialog::Accepted) {
            insertMark(dialog.markSelect->currentText().toInt(), dialog.subjectSelect->currentText());
        }
    });
}

void MarksWidget::insertMark(int mark_, const QString &subject) {
    QListWidgetItem* item = new QListWidgetItem(marksList.get());
    marksList->addItem(item);
    Mark* mark = new Mark;
    mark->setMark(mark_);
    mark->setSubjectTitle(subject);
    item->setSizeHint(mark->minimumSizeHint());
    marksList->setItemWidget(item, mark);
    marksList->scrollToBottom();
}
