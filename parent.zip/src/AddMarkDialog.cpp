#include "../include/AddMarkDialog.h"

AddMarkDialog::AddMarkDialog(QWidget *parent) :
        QDialog(parent),
        layout(new QFormLayout(this)),
        subjectSelect(new QComboBox(this)),
        markSelect(new QComboBox(this)) {
    setWindowTitle("Добавление оценки");
    initWidgets();
    initLayout();
    initConnections();
}

void AddMarkDialog::initLayout() {
    setLayout(layout);
    layout->addRow("Оценка", markSelect);
    layout->addRow("Предмет", subjectSelect);
    layout->addRow(buttonBox);
}

void AddMarkDialog::initWidgets() {
    for (int i = 1; i <= 5; ++i) {
        markSelect->addItem(QString::number(i));
    }
    subjectSelect->addItem("Информатика");
    subjectSelect->addItem("Алгебра");
    subjectSelect->addItem("Геометрия");
    subjectSelect->addItem("Русский язык");
    subjectSelect->addItem("Физика");
    subjectSelect->addItem("Биология");
    subjectSelect->addItem("Химия");
    subjectSelect->addItem("Физкультура");
    subjectSelect->addItem("Английский язык");

    buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok
                                     | QDialogButtonBox::Cancel);

}

void AddMarkDialog::initConnections() {
    connect(buttonBox, &QDialogButtonBox::accepted, this, &QDialog::accept);
    connect(buttonBox, &QDialogButtonBox::rejected, this, &QDialog::reject);
}