#include "../include/ParentCentralWidget.h"

ParentCentralWidget::ParentCentralWidget(QWidget *parent) :
        QWidget(parent),
        mainLayout(std::make_shared<QGridLayout>()),
        marksWidget(std::make_shared<MarksWidget>(this)),
        summaryWidget(std::make_shared<SummaryWidget>(this)),
        plotWidget(new PlotWidget(this)) {
    initWidgets();
    initLayout();
    initConnections();
}

void ParentCentralWidget::initWidgets() {
    setLayout(mainLayout.get());
}

void ParentCentralWidget::initLayout() {
    mainLayout->addWidget(marksWidget.get(), 0, 0, 2, 1);
    mainLayout->addWidget(summaryWidget.get(), 0, 1, 1, 2);
    mainLayout->addWidget(plotWidget, 1, 1, 1, 2);
}

void ParentCentralWidget::initConnections() {

}