#include "../include/SummaryWidget.h"

SummaryWidget::SummaryWidget(QWidget *parent) :
        QWidget(parent),
        mainLayout(std::make_shared<QGridLayout>()),
        minutesTitleLabel(std::make_shared<QLabel>()),
        levelTitleLabel(std::make_shared<QLabel>()),
        minutesLabel(std::make_shared<QLabel>()),
        levelLabel(std::make_shared<QLabel>()),
        minutesEdit(std::make_shared<QLineEdit>()),
        minutesAdd(std::make_shared<QPushButton>()) {
    initWidgets();
    initLayout();
    initConnections();
}

void SummaryWidget::initWidgets() {
    setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
    setLayout(mainLayout.get());

    minutesTitleLabel->setText("Доступно минут:");
    levelTitleLabel->setText("Уровень ребенка:");

    minutesLabel->setText("100 мин.");
    levelLabel->setText("3 lvl.");

    minutesEdit->setPlaceholderText("Сколько минут добавить/убрать?");

    minutesAdd->setText("OK");
}

void SummaryWidget::initLayout() {
    mainLayout->addWidget(minutesTitleLabel.get(), 0, 0, 1, 1, Qt::AlignLeft);
    mainLayout->addWidget(minutesLabel.get(), 0, 1, 1, 2, Qt::AlignRight);

    mainLayout->addWidget(levelTitleLabel.get(), 1, 0, 1, 1, Qt::AlignLeft);
    mainLayout->addWidget(levelLabel.get(), 1, 1, 1, 2, Qt::AlignRight);

    mainLayout->addWidget(minutesEdit.get(), 2, 0, 1, 2, Qt::AlignLeft);
    mainLayout->addWidget(minutesAdd.get(), 2, 2, 1, 1, Qt::AlignRight);

    mainLayout->setColumnStretch(0, 1);
    mainLayout->setColumnStretch(1, 0);
}

void SummaryWidget::initConnections() {
    connect(minutesAdd.get(), &QPushButton::clicked, this, [&]() {
        if (minutesEdit->text().isEmpty()) {
            QMessageBox::warning(this, "Ошибка ввода", "Поле с минутами не должно быть пустым");
            return;
        }
        bool correct;
        int inputedMinutes = minutesEdit->text().toInt(&correct);
        if (!correct || inputedMinutes <= 0) {
            QMessageBox::warning(this, "Ошибка ввода", "Введите положительное число для добавления минут");
            minutesEdit->clear();
            return;
        }
        auto items = minutesLabel.get()->text().split(' ');
        int current_minutes = items.first().toInt();
        minutesLabel->setText(QString::number(current_minutes + inputedMinutes).append(" мин"));
        minutesEdit->clear();
    });
}