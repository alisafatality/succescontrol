#include "../include/PlotWidget.h"

PlotWidget::PlotWidget(QWidget *parent) :
        QCustomPlot(parent){
    qint64 now = QDateTime::currentDateTime().toSecsSinceEpoch();
    qDebug() << now;
    // generate some data:
    QVector<QCPGraphData> timeData(7);
    srand(time(nullptr));
    for (int i = 0; i < 7; ++i) {
        timeData[i].key = (double)now + 24 * 3600 * i;
        timeData[i].value = rand() % 5 + 1;
    }
    QSharedPointer<QCPAxisTickerDateTime> dateTicker(new QCPAxisTickerDateTime);
    dateTicker->setDateTimeFormat("d. MMMM\nyyyy");
    xAxis->setTicker(dateTicker);
    xAxis->setTickLabelFont(QFont(QFont().family(), 8));

    addGraph();
    graph(0)->setName("Оценки за неделю по ИКТ");
    graph(0)->data()->set(timeData);
    xAxis->setLabel("Даты");
    xAxis2->setVisible(true);
    xAxis2->setTicks(false);
    xAxis2->setTickLabels(false);
    xAxis->setRange((double)now, (double)now + 24 * 3600 * 7);
    yAxis->setLabel("Оценки");
    yAxis->setRange(0, 6);
    replot();
}

void PlotWidget::init() {

}
