#include "../include/ChildrenListWidget.h"

ChildrenListWidget::ChildrenListWidget(QWidget *parent) : QListWidget(parent) {
    insertChild("Иванова София Дмитриевна");
}

void ChildrenListWidget::insertChild(const QString &fio) {
    QListWidgetItem* item = new QListWidgetItem(this);
    addItem(item);
    ChildItem* child = new ChildItem;
    QPixmap pixmap("../assets/kid_avatar.png");
    child->setAvatar(pixmap);
    child->setFIO(fio);
    item->setSizeHint(child->minimumSizeHint());
    setItemWidget(item, child);
}
