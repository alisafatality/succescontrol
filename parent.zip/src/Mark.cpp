#include "../include/Mark.h"

Mark::Mark(QWidget *parent) :
        QWidget(parent),
        layout(new QGridLayout(this)),
        mark(new QLabel(this)),
        subject(new QLabel(this)) {
    initLayout();
    initWidgets();
}

void Mark::setMark(int mark) {
    this->mark->setText(QString::number(mark));
}

void Mark::setSubjectTitle(const QString &subject_title) {
    subject->setText(subject_title);
}

void Mark::initLayout() {
    setLayout(layout);
    layout->addWidget(mark, 0, 0, 1, 1);
    layout->addWidget(subject, 0, 1, 1, 4);
}

void Mark::initWidgets() {
    mark->setText("5");
    mark->setAlignment(Qt::AlignCenter);
    mark->setStyleSheet("background-color: #f2f2f2; border-radius: 16px; color: black;");
    subject->setText("Информатика");
}