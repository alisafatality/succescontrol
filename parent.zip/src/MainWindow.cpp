#include "../include/MainWindow.h"

MainWindow::MainWindow(QWidget *parent) :
        QMainWindow(parent),
        centralWidget(std::make_shared<QWidget>()),
        mainLayout(std::make_shared<QGridLayout>()),
        childrenListWidget(std::make_shared<ChildrenListWidget>(this)),
        parentCentralWidget(std::make_shared<ParentCentralWidget>(this)) {
    setWindowTitle("Контроль успеха");
    resize(QSize(800, 400));

    initWidgets();
    initLayout();
    initConnections();
}

void MainWindow::initWidgets() {
    setCentralWidget(centralWidget.get());
    centralWidget->setLayout(mainLayout.get());
}

void MainWindow::initLayout() {
    mainLayout->addWidget(childrenListWidget.get(), 0, 0, 1, 1);
    mainLayout->addWidget(parentCentralWidget.get(), 0, 1, 1, 1);

    mainLayout->setColumnStretch(0, 0);
    mainLayout->setColumnStretch(1, 1);
}

void MainWindow::initConnections() {

}
